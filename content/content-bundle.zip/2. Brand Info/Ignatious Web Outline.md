**

WE ARE IGNATIOUS 

  

CANDY STORE WEBSITE OUTLINE (EVERY POSSIBLE PAGE): WHY ARE YOU DIFFERENT AND WHY SHOULD THEY CHOOSE YOU

  

1. High Level Themes
    

1. What we do: Help great technology companies capture extraordinary outcomes for their founders and investors.
    

1. We help great technology companies capture extraordinary outcomes for their founders and investors.  
    
2. We are in the value and liquidity maximization business, the certainty business, the risk reduction business and the vision-realization business.  
    
3. We provide a comprehensive and optimized solution across the entire spectrum of these stakeholder goals
    
4. We work intimately with you and your team to capture the highest valuation with the most certainty and lowest in the most time and resource efficient manner
    
5. We seek to provide not just the best advisory services, but most importantly to provide an extraordinary outcome.
    

3. From Idea to Icon/Iconic (not sure which is better, as both have pros and cons)
    

1. Phases
    

1. START: From Idea to Starting a company is Passion (Ignatious means fiery passion)
    
2. EXECUTE: From Starting a Company to Building a Great Company is VC
    
3. CAPTURE: From Great Company to Becoming Iconic is Ignatious
    

3. “Manifest / Destiny” the dual meaning of this was your destiny (which they believe), and the spiritual notion of what you manifest becomes your destiny
    
4. Note that Ignatious, Idea to Iconic and Manifest / Destiny were all chosen because they also have two “i’s” in them
    
5. Yes wealth is nice, but stature makes it repeatable.  And that is our dream - make you repeatable. As the world can’t lose its hero’s to the comfort and trappings of wealth.  Elon still at it with $300bb.  And Steve Jobs, and ….  
    

5. Important concepts to note about our name
    

1. Ignatious means fiery or passionate… what WE are as well as every founder that ever started a successful company
    
2. The two i’s are very important, as they represent the theme of the company: from Idea to Icon/Iconic
    
3. We also like using Ignatious as an adjective: We look to deliver an Ignatious Outcome for our partners (Extraordinary Outcome)
    

7. Key Messages to Convey
    

1. Bending the Future, One Great Company at a Time/Elevating One Great Company at a Time; Bending the Future with the World’s Greatest Entrepreneurs; Helping the world’s greatest entrepreneurs bend the future in unimaginable ways
    
2. We elevate great entrepreneurs, the companies they run and the investors that support them
    
3. Our goal is to accelerate the entrepreneurial path from idea to icon
    

1. Ideas without a Great entrepreneur are worthless 
    

1. You are the “I” in “Idea”
    

3. Implementation brings forward a great new company to the world
    
4. But Iconic companies and entrepreneurs change the world
    
5. Elon Paypal -> Solar/Battery/EV/SpaceTravel/Free Speech/Underground Highways
    

3. General Design/Layout
    

1. Simple… minimal text, minimal images, minimal clutter
    

1. Land on a page with only a Tagline (one that Inspires the mind and curiosity and aspiration of the user)
    
2. Shortly after a small amount of text arrives that explains it (or is this too slow/too much motion, which I don’t like… and the text should be there from the beginning?)
    
3. Have elements that don’t reload (keep tabs the same each time and logo, etc…. Just the new content loads
    

3. SEO
    

1. Keywords (M&A, Mergers, Acquisitions, Sell [my] company, SPAC, Advisory, Buy Side, Sell Side, Advisory, Strategic Advisory, Financial Advisory, Capital Raise, Technology, Technology M&A, Best M&A Advisor, etc.)
    

1. How do we find out other keywords that are critical?
    

3. Alt Text on Images
    

5. Embedded Analytics and User Tracking
    
6. Subscribe to our Newsletter
    
7. Worked with us before? Leave a Review!
    

5. Logo
    

1. We are in love with the current logo and visual representation of our brand that was created by TinyWins - unless some visionary dream comes to the designers in the middle of the night that elevates it even more, we don’t think it needs any changes (unless slight tweaks on color or the icon to better represent our theme)  
      
    

![](https://lh6.googleusercontent.com/Xo-Xqp81urzUC4hy7ENJrqnSJF-nS4pVyJ5ZHWv0u5Uu6DJeMIJCsgIx2Gx1yCMvQLrk6YfMUuY_4M6oSuOsKgcdhMPrmgRe6kz5OHWUi0qV1LhQ--SvtWJNwueJyMVkIIdNqd5PN0_H6sZwQTpcNYs)

2. Discuss how/whether/when to incorporate “Growth Capital & Advisory” into logo when necessary
    
3. Need Logo collateral for our files (square and rectangular; just logo/logo and Ignatious/ Logo and Ignatious and Growth Capital & Advisory, white, black and transparent backgrounds, various sizes and formats, etc.)
    

4. Outline (KRISTEN TO EDIT)
    

1. You
    

1. Tagline: [Heroes/It’s Your Time/Now It is Your Turn/There is No Finish Line; Heroes Have No Finish Line/Shape Shifters]
    

3. Why
    

1. Tagline: Entrepreneurs Are Our Heroes
    

5. What
    

1. Tagline: [Elevating Icons/We Take You There/Two Steps Forward]
    

7. How
    

1. Tagline: [Unrelenting Advocates/Strategic Thinkers and Doers]
    

9. Who
    

1. Tagline: [30 Years of Bending the Future/Seeding the Fields of the Future/ Seeding the Future]
    

11. Downstream we will add:
    

1. Learn
    

1. Tagline: Bending the Mind
    

3. Just Cause
    

1. Tagline: Good. Gracious. Ignatious.
    

6. Landing Page
    

1. Very short, simple page that is a launching pad into the rabbit hole of our site
    
2. Tagline: “Manifest / Destiny … From Idea To Iconic”
    

1. Idea: Have the divide sign be the ignatious logo or fades into or out of it
    
2. Idea: Have the I from Ignatious Be the middle line (“GNATIOUS” disappears and the first I stays and becomes the Middle line, breaks into two more I’s: Idea to Icon): Idea | Icon
    
3. Idea: Manifest / Destiny Shows up in our same logo font
    

1. Two I’s drop down and fill in “Idea to Iconic” (or up) (From Idea to Icon matches with Manifest / Destiny Theme)
    
2. Two I’s drop down again and fill in Ignatious (or up)
    

4. Design
    

1. Start with black background and only: “Manifest / Destiny” (many layers of those words, including very appealing to CEOs and other people with a big enough ego to leave everything they have been taught and take a risk of starting a company or buying a transformative company for a big price)
    
2. Have the scroll over highlighting from TinyWins
    

6. Then use the animation and the four dot logo to tell our verbal story
    

1. Add Ignatious without logo icon
    
2. From Idea to Icon: 
    

1. Highlight first “i” and animate it into “Idea”; 
    
2. Then highlight second “i” and animate it into “Icon”
    
3. Have this turn into “From Idea to Icon”
    

4. Do something with turning an “i” into a growth curve and then it becomes the four dotted line logo?
    
5. Then move to the logo and name to the spot at the top of the page
    

8. Add copy (choose from these two, first is more accurate, second is more powerful): have this somewhere where it is obvious they can and should read it, but it isn’t on the page full time so we don’t overwhelm them with content
    

1. Whether you are a Company at the early stages of the change you seek, a time-tested growth technology company, or an established company looking to acquisitions to turbo charge your transition to a technology-future, our team can successfully execute upon your goals through our unmatched M&A and capital raising expertise.    
    
2. We do one thing and we do it well: help growth technology companies, their visionary founders and the investors that support them maximize the value of their company through our unmatched M&A and capital raising expertise.
    

10. Call to Action: Partner for a Better Future
    

  

6. Why We Do This/Why We Exist
    

1. Tagline: Heroes/Entrepreneurs are our Heroes
    
2. Key Messages to Convey
    

1. Great entrepreneurs bend the future
    
2. They have no finish line
    

1. There is no finish line, but first you need to get to the starting line (elevate yourself).
    

4. Why does Elon musk have so much power.  Because he sold PayPal and freed himself from tasks/execution to strategy, and elevated himself into the dialogue.  Or Bill Gurley or ….
    

1. Entrepreneurs are our heroes, but need elevated to their true potential (implementing vision and achieving mission and not executing tasks)
    

6. The world deserves a better future
    
7. We support these heroes, from idea to icon
    

4. Story/Copy
    

1. Entrepreneurs are our heroes.
    

  

These visionary innovators and out-of-the-ordinary leaders see solutions where others see problems, see hope where others see obstacles, and unabashedly tie their shoes each morning and run toward a better tomorrow. They take on the most astonishing challenges and, in the process, bend the future in unimaginable ways that benefit all of humanity.

  

We built Ignatious with the sole purpose of assisting these entrepreneurial agents of change to achieve their better-is-possible vision and maximize the value of what they are building. 

  

We do one thing and we do it better than anyone else: help great technology companies capture extraordinary outcomes for their founders and investors. And in capturing this deserved outcome for them, Ignatious helps these companies and their leaders transcend to an Iconic status so they can continue to shape the future in even greater ways.

  

From Ideas to Icons, we are Ignatious.

  

2. Call To Action
    

1. If you are a founder, CEO, VC, Corporate Acquirer looking for technology targets to turbo charge your company, or any other creator of a better future, our team can successfully execute upon your goals through our unmatched M&A and capital raising expertise.
    

  

4. Founding Origin Story
    

1. It wasn’t too long ago that my daughter asked me, “Daddy: what do you do?” 
    

  

This felt easy to answer when anyone else had asked, I had perfected the standard investment banker answer. 

  

But when she asked, I knew she wanted me to be her hero, and I froze. What is it that I do? And why do I do it? 

  

I didn’t feel like the hero I wanted her to look up to, sitting in a me-too bank chasing the same empty path as every other investment banker. 

  

In short, I needed a new answer… and that answer became Ignatious. 

  

As much as we all want to be the hero, the true heroes are the bold entrepreneurs who risked everything to create a better world for our children.  I realized I’m more Yoda than Luke Skywalker, and that my best contribution to my daughter's world would come from providing my extraordinary gift of marketing and negotiating to help these visionary leaders and their companies fulfill their heroic missions. 

  

At Ignatious, we do one thing: help growth technology companies, their visionary founders and the investors that support them, to maximize the value of their company through our unmatched M&A and capital raising expertise. We help make these entrepreneurs and their companies iconic, so they can continue bending the future in even greater ways.

  

And we do this extremely well. 

  

This is why I founded Ignatious, and that is why we won’t stop.

  

How can we help you achieve your Ignatious goals? 

  

7. What We Do: Bend the Future
    

1. Tagline: “Unrelenting Advocates”
    
2. 30 Years of Bending the Future
    

1. Bent Timeline with most important deals over time
    
2. Examples
    

1. Exclusive financial advisor to Google for 10 years.  
    
2. Highest returning acquisition in history (Google's acquisition of YouTube); 
    
3. Sold the first DARPANET node (to AOL)
    
4. Sold a company for $270mm two days before they were filing for bankruptcy
    
5. Led the only equity recovery ever for a software company in bankruptcy.
    
6. Sold Sun Microsystems to Oracle
    
7. Sold Java to Sun Microsystems
    
8. Others?
    

9. How We Do This
    
10. Who Are We?
    

1. Tagline
    
2. Idea to explain who we are
    

1. Have a handwritten markup of our logo to explain it in detail such that it also shows who we are (hire an artist to make it look real but nice)
    

1. No better way to explain the name and who we are than this (ties it all together in a memorable way)
    
2. Idea to Iconic & Manifest / Destiny (two i’s in each and in our name)
    

1. The slash between manifest / destiny is our logo
    

4. From I to US (the power of working together)
    
5. The “power of” symbol (get exponentially better outcomes)
    
6. Fiery and Passionate (definition)
    
7. The tilted i… growth with the dot of the i being the breakout moment of becoming iconic
    

4. Who We Are Not
    
5. Our Team
    

1. Bios
    
2. Click to Call
    
3. Click to Email
    
4. Click to Text
    

12. Who Are You/Where Are You Going
    

1. Tagline: 
    
2. Why Ignatious/Why Be Ignatious
    
3. The Entrepreneurs Journey
    

1. Ark
    

5. Because your company deserves…
    
6. Who We Work With
    
7. Do You Need Us
    

1. 90% of deals have one buyer
    
2. Price isn’t everything: certainty, speed, etc.
    

9. You are a leader, an Icon in the Waiting room/Making, that sees a better future for the world by virtue of you and your company.  You might be a founder or a buyer or investor, but in any case you realize that the possibilities for change are enhanced with a partner that helps you take your company to another level
    

1. The benefit of this phrasing is that it addresses both buyers and sellers and capital sources
    

11. [The Ezra Klein Show](https://substack.com/redirect/697de6e6-2a76-419d-88c2-d828e0824ed1?u=8591270) (Kim Stanley Robinson) (Quote on the type of people we want to work with)
    

1. In our culture, to say you’re optimistic is maybe not the right thing, but hope, optimism… this attitude is a necessary stance to take because we are in a position of privilege and the situation can be saved and given those two, it’s dereliction of duty to be pessimistic, to be cynical. It’s just a chicken thing to do. 
    
2. We need to be strong in a moment of crisis by saying, yes, it can be done. And if we’re in a race between bad catastrophe and some kind of beginning prosperity for all — when you’re in a race that intense, you don’t want to sit down on the ground and start crying. Oh, we’ve lost already. That would be a bad thing to do, because you’re in a race.
    
3. You actually need to run as hard as you can. If you lose the race, well, that is a dystopian novel. And I don’t really want to go there. If we lose the race, we’re in terrible trouble, and we’ll be in emergency mode for years. But if we win the race, it’s a big win for the biosphere, for the other creatures, for humanity. So it’s worth pretending to be optimistic, or using optimism as a club, and beating it with people. Yes, we can succeed. Bang, bang, bang.
    
4. Longtermism is about taking seriously just how big the future could be and how high the stakes are in shaping it. If humanity survives to even a fraction of its potential life span, then, strange as it may seem, we are the ancients: we live at the very beginning of history, in its most distant past. What we do now will affect untold numbers of future people. We need to act wisely.
    

14. The Fine Print
    

1. We Negotiate For You, Not Against You
    
2. We compete on outcomes, not fees
    
3. Our Fee Scale
    

16. Join our Team
    

1. Tired of being undervalued. Tired of being fed focused rather than passion/purpose/ client focused? Tired of pitching the same fucking deals as every other bank underneath an MD that doesn’t know what they are doing and only wants to own a bigger home off of your back?
    

18. Just Cause (Good, Gracious, Ignatious)
    

1. (Our Charitable Contributions)
    

20. Learn
    

1. Blog
    
2. Newsletter
    
3. Prodcast
    

22. Future Pages
    

1. Every podcast, blog, newsletter should have a call to action.
    

24. Other Collateral needed
    

1. Style Guide
    
2. Word Letterhead
    
3. Email Footer
    
4. Powerpoint Template
    

1. Standard chart/graphs colors
    

6. Newsletter layout
    
7. Zoom background
    

  
  

WHY WE EXIST

  

Entrepreneurs are our heroes.

  

When transportation or education fail, who jumps in?  When climate change or pandemics emerge, who jumps in? When the government fails, who jumps in?  

  

It is the visionary innovators and out-of-the-ordinary entrepreneurs who see solutions where others see problems, see hope where others see despair, and who tie their shoes each morning and unabashedly run toward a better tomorrow.  These future-shifters/future benders/future bending leaders drive forward with meaning and purpose, and take on the most astonishing journeys.

  

Our new world requires these intrepid entrepreneurs who take the leap of faith from the comfortable and safe into a life where the desire to create a better world transcends creature comforts.

Second option: into a life that transcends creature comforts, in order to help reshape the world around us in mind-bending ways.

  

At Ignatious, we have an insatiable pull to do something significant, to make the impossible, possible.  We foresee a tech-enriched world where humanity lives in harmony. 

  

We founded Ignatious with the sole purpose of helping purpose-driven entrepreneurial agents of change achieve their “better-is-possible” vision and maximize the value of what they are building.

  

We do one thing and we do it better than anyone else: help great companies capture extraordinary outcomes for their founders and investors.  And in capturing their rightful outcome, Ignatious help these companies and their leaders become Iconic so they can continue to shape the future in even greater ways.

  

Our ideas, our effort, our experience,our passion and our commitment to the greater good represent our entrance fee to this formation festival… not our social status or gender or race or uniqueness relative to the herd.

  

Empower World Shifting Technology Companies to Greater Impact

Shift world changing technology companies to a higher level

To achieve their maximum potential

To grasp their maximum potential 

  

Call to Action: Whether you are a Company at the early stages of the change you seek, a time tested growth technology company, or an established company looking to acquisitions to turbo charge your transition to a technology-future, our team can successfully execute upon your goals.

  

“We founded Ignatious to help the best technology businesses change the world.  We don’t compete with investment bankers who define success each bonus season, we compete against a higher standard.”

  

Founder & Managing Partner

Storm Duncan

  

“One of the reasons I first started The Generalist was because I believe that the great epics of our era will occur in the tech sector. No other field asks – and tests – so many consequential philosophical, psychological, and societal questions so frequently. What is money? What makes something valuable? Will nations exist in the cloud? Can we hack our bodies? Must we die? Every year, startups emerge to explore these questions and others, setting out on ambitious adventures.”

Add copy on decisioning:

What had the most impact on the world 

What can be bent positively 

How can I bend it 

That’s Ignatious 

Bending the future in your favor 

  
  

WHAT WE DO

  

We do one thing: help great entrepreneurs and their investors maximize the value of their company [through our unmatched M&A and capital raising experience]. 

  

Help growth technology companies, their visionary founders/entrepreneurs and the investors that support them secure the highest value for their company with the most certainty and least risk through our unmatched M&A and capital raising expertise.

  

We Help Great Companies come together. (this one speaks more to the aspect of buyers and sellers.  

  

We take growth technology companies two steps forward in their destination to a new level of success, [whether it's merging into a larger partner, buying a strategic target, raising capital in the private markets, or taking the leap into the public markets.]

  

While some call this the finish line, the companies and entrepreneurs who run these agents of change see it as just the beginning, as impact has no finish line. As soon as they reach this mislabeled destination, the greatest entrepreneurs realize the powerful force they bring to humanity is a journey not only without boundaries but also without a finish line.

  

[Your audience needs to understand the problem your idea solves. Don’t leave them guessing. Explain it clearly]

  

HOW WE DO THIS

  

Just like your path was not linear, no strategic or financial process takes the same path.  

You are different

Your goals are uniquely yours

Buyers and Investors have their own goals and their own fears

  

We are in the value and liquidity maximization business, the certainty business, the risk reduction business and the vision-realization business.  We provide a comprehensive and optimized solution across the entire spectrum of stakeholder goals

  

We learn and understand not only what the company solves, but the incremental value to each buyer in that solution

1. We Play the Buyers Hand.
    
2. We position the company for its best value]
    

  

We ask the right questions, as our experience has taught us that answers are not static or generic.  Getting the highest value is a cheap answer to what we can do.  Oftentimes certainty, risk reduction, speed or sourcing and aligning with the right partner can provide more to stakeholders than the highest upfront optical value, especially in the technology market where valuations can be volatile.

  

We simplify complex strategic and financial processes, remove friction and add value in the form of leadership, experience and connections.  We help accelerate and navigate your journey to arrive at your desired destination as effectively as possible.

  

Our bottom line: we combine our unparalleled experience, track record and passion to accelerate the success of leading growth technology companies and their potential strategic acquirers.  We like to call this… Morementum.

  
  

WHO WE AREN’T

  

We are not the hero, you are: Unlike bankers who view themselves as the hero and can’t wait to talk about their company, we view entrepreneurs as the hero and we can’t wait to talk about your company.  We are partners, advisors, and confidants…. Investment bankers lie on another side of the table from Ignatious.

  

We define your success as our success. We advise as principals and owners, not as agents. We dedicate ourselves to the vision of our client-partners and to championing their dreams instead of being a victim of our personal ambition.

  

We invest profit in new emerging companies that bend the future.  We donate to those innovating in new ways of caring for others who haven’t the same beneficial circumstances.

  

We have been on both sides of the investment banking culture.  Far too many bankers are chasing wallets, when they should be supporting the audacious mission of their clients. We are not a soulless army of 6,000 bankers engaged in a daily battle to generate enough revenue to cover our wood paneled offices, first class flights and excessive bonuses at our customers expense.  

  

Investment Bankers are the IRS of the innovation world, feeding off of the success of others.  Banking has a crisis of culture, viewing each company in the single context of their year end bonus.  “A ferrari, a table at the latest club, a third home… what more can I buy for myself.”  

  
  
  

WHO WE ARE

  

Strategic thinkers and doers.

  

We are shape shifters.  For over three decades we have represented the best companies in the world to expand their success.  We sold AOL the DARPANet node, secured AMD’s future leadership in CPUs with the sale of Nexgen, we brought YouTube and DoubleClick into the Google Family, we sold Java and Sun to Oracle, we sold Apple its first full stack autonomous vehicle company, we helped secure Uber’s leadership in 12 countries outside of the US, amongst many other groundbreaking transactions.

  

Experienced.  We have spent our entire careers executing complex, future-oriented strategic and financial transactions.  In addition to Google, Uber and Oracle, we have worked with Tencent, Alibaba, Microsoft, Facebook, Hewlett Packard, SAP, IBM, Applied Materials, L’Oreal, and Nestle amongst many other leading global brands.  We have sold technology companies to IBM, Johnson & Johnson, 3M, AMD, Benckiser, Boston Scientific, and many many others.

  

Passionate. Our ethos stems from the simple guiding philosophy: deliver extraordinary outcomes to the world's best entrepreneurs.

  

Partners.  We operate as owners and partners, not as agents.  We are without any doubt partners in the success of our clients, and our success derives solely from our ability to meaningfully amplify our client-partner’s success.  In fact, everyone on our team has the title of partner because we believe we are all irrevocably responsible to the outcomes we seek. And that responsibility rests in every single partner on our team, from the janitor who keeps us flowing, to the Managing Partner who keeps us going.

  

CASE STUDY

  

When the ride hailing company Careem approached our team, their mission was clear: 

Simplify and improve the lives of people by providing affordable first world caliber transportation in over a dozen countries. The problem: they were competing with a heavily funded and experienced global competitor in Uber.

  

We successfully negotiated a merger of Uber’s competitive businesses with Careem that provided our client’s shareholders $3.4 billion in cash while still retaining upside on the Uber stock.  We also won a hell or highwater closing provision, one of the very few ever. 

  

The merger not only reduced operating costs significantly, but eliminated a competitor and provided growth capital at the same time.  Additionally,  the Careem brand name was held and the Careem management team remained in a leadership role. 

  

THE RESULT- Beyond-Extraordinary economics for our client parnter while still maintaining the surviving entity… we call this an Ignatious outcome.

  

CORE VALUES THAT DEFINE US (needs to be tightened)

  

Our success is a byproduct of helping our clients achieve their success

  

Act Like Owners: We don’t believe in principle/agent roles, the best advice comes from those who operate like owners (shared alignment)

  

Work together, win together: We define team to include our clients, consultants and our full ecosystem of partners

[AND/OR] Clients: Our clients are full partners with us, and we are full partners with our clients

  

Team: 

We look out for and take care of each other

We encourage full coordination, cooperation and gang tackling

We champion mutual respect and kindness throughout all phases of growth and development

  

Never compromise on our principles or ethics

  

We care about your company

  

We are passionate about what we do and what you do

  

HEART WARMING COPY TO USE AS NECESSARY

  

Being an entrepreneur isn’t easy. In fact, it is unimaginably difficult.

  

You start off with an idea you believe in, but no one else does (otherwise they would have joined you).  Just you… and an idea.  

  

Your first asset is a napkin, and your first office became available only when the 10 year old car parked inside was evicted into the driveway.

  

Every day posed new challenges to achieving your mission.  Promised capital disappeared.  Recruits turned down offers.  Customers didn’t sign on time, or at all.

  

But you didn’t lose your out-of-this-world focus and determination, your work ethic or your belief in yourself and your vision.

  

Then it started to click.  Slowly the value proposition came to life, and you made one customer happy. In fact, more than happy.  

  

That didn’t suddenly eliminate the hard work, though, nor did it eliminate what is left to do.  It was never easy and it never will be easy.  

  

You’ve arrived, but it still feels like you are just beginning. 

  

We understand not only what you’ve been through, but also what you have left to accomplish.  And because we are invested in your vision, we are irrevocably tied to your outcome as well.

  

[they call it a “minimum value propostition”, you called it “just the beginning”]

  

WE ARE IGNATIOUS [AND WE WON’T STOP] 

  
  

CALL TO ACTION [Sellers.  Buyers.]

  

Entrepreneurs

You’ve been approached.  Maybe it is by an acquirer.  Maybe it is by a new investor, an existing board member or one of your partners.  It might even be by your significant other or family or friends.

  

They’ve posed one simple question to you, is there a better path for the Company to achieve its mission?  Maybe they think you should raise additional capital, seek a public listing or even merge into a bigger, well-capitalized partner that can accelerate your vision with faster customer growth, a higher margin or a lower cost of (more) capital.

  

So you ask yourself, is now the time to consider one of these paths?

  

Even if you agree, you are torn.  This is your creation, this is your dream. Can you share control of your vision and legacy with another partner?  Is it time to dilute or even exit the early supporters in favor of a partner more aligned with a new level of success.

  

We understand these are difficult questions to navigate, and that is why we created Ignatious.

  
We don’t merely sell companies or raise capital, we help growth technology companies achieve their audacious goals… and our success is entirely the byproduct of helping our clients achieve their goals.

  

Established Companies: Buy or Die

You have a phenomenal world class brand, profits and growth, but each morning new technology companies wake up with the single minded pursuit of taking your profit.  With new technologies and untethered from legacy, they approach your customers with the promise of a new song and ask for a first dance.  You can either see these companies as threats, or you can see them as Ignacious opportunities - off balance sheet investments in innovation and growth and efficiency and cultural evolution that can further elevate your company’s status and position in the market.  

  

Whether you are only at the early stages of the change you seek, a time tested growth technology company, or an established company looking to use acquisitions to accelerate your transition to a technology-future, our team can successfully execute upon your goals.

  

Let us help you achieve your Ignatious Goals.

  

CRITICAL MESSAGE TO COMMUNICATE (BUT NOT LEAD WITH)

  

Been here forever - established, trust

Extraordinary Outcomes

  

TAGLINES

SHORT CATCHY PHRASES

Safe is for Others

Seeding the Future

Companies of Consequence (A VC’s)

Bend the Future (“BTF”)

Delivering Extraordinary Outcomes to Tech Companies

Helping Entrepreneurs Bend the Future

CTA: Let’s do Something Important together

Let’s do Important together.

We Do Important Together

The power of us.  The Power of Ignatious.

Now Elevating Heroes

Elevate yourself

We take you there

Rebels with a Cause

It’s Time

It’s Your Time

Behind every hero, there’s a [team/Yoda metaphor]

We are not the hero, you are

You are the hero, not us

We are Ignatious, and you are the Hero

(Unlike bankers where they want to be the hero)

Shape Shifters

We change your trajectory (image of a  trajectory being moved up… line to parabola or step function)

We bring certainty to an uncertain world

We put companies in a place to change history

We Change history one future at a time

Change history one partner/company/deal at a time

Change the future one…

Two Steps forward/Two Steps Ahead

No steps back

We like to call it… Morementum

Morementum (Great Blog Post)

This is/That’s Ignatious Thinking 

Innovators, not imitators

We do one thing: [help the world’s best technology company realize their vision/mission/goal]

We are here to accelerate your success

We are here to solidify your success (this one is most accurate)

We are here to increase your impact

We exist to help you make your difference in the world

We help you reach your destination

We are Ignatious, and We Won’t Stop

Unrelenting Advocates

Impact has no finish line

We are in this for our children, not for our ego

We Care  
⚡ > $$

♥️ > $$ 

The goal is fixed, but the path is dynamic

The path is dynamic, the goal is static/fixed

The Finish Line

Like no one else

Prodcasting

Just ‘Cause

Optimizing the Human/Human Experience

Optimizing the Planet

No Surprises

Invest in yourself, we take care of the rest

Invest in yourself, We’ll find the co-investor

Lighting up the world with you

We help you light up the world

Love knows no borders

We act as owners, not agents

We act as Principles, NOT agents

Operate at the forefront of technology

We allow you the freedom to run your business

Table Stakes

Outcome that Matter

Extraordinary Outcomes 

Outcome Banking

Impactful Outcomes

Creators of Ignatious Outcomes

  

LONGER/CONCEPTS (not catchy)

We help great entrepreneurs and their investors maximize the value of their company. 

  

We help great entrepreneurs fully realize their potential

  

We help elevate entrepreneurs and their investors by securing higher values for/maximizing the value of their company

  
  
  

Helping the greatest tech entrepreneurs and companies extract the full value of their work and vision.

  

Our success is the unintended side effect of our client’s success. 

  

Our dedication to the vision of our client-partners and championing their dreams instead of being a victim of our ambition.

  

Far too many bankers are chasing wallets, when they should really be in the market for hearts (Passion)

They don’t value their employees or invest in their culture

  

IGNATIOUS THE NAME (WHY WE CHOSE IT)

  

Fiery, enthusiastic, passionate burning

Progress requires great effort and time, but achieving great things requires passion bordering on obsession

An idea burning inside you so intensely that it has to come to the surface

What is under the surface eventually can not be restrained and bursts out in all of its glory

Like emerging technologies: erupts quickly and with heat and passion and quickly takes over its space

  

“Ignatious”: (adj) A burning or fiery passion for helping advance a better tech based future for our children; (noun) A group of professionals assembled for the sole purpose of helping those developing a better tech based future for our children.

Example use: The world deserves the full success of Mojio’s ignatious mission.

  

STORM’S BIO

  

Storm has been actively involved in the technology sector for nearly 30 years, and has successfully sat on all sides of the table – founder and CEO, investor, advisor, and board member.  

  

IMAGERY

  

Spider webs: Strength without weight, interlinked, captures only what it needs to capture but let’s everything else pass

Yoda

Young founders (Steve Jobs, Elon Musk, Sam Walton, Vitalik)

Tesla Coil

Lightning bolt like an S

  

VIDEO

  

Tell my Stories of YouTube, Careem, NetFish, PayPal

  

Daddy: what do you do?

MY daughter asked me while we were engaged in a ferocious battle with our blue and red light sabers.

When she asked me, I froze.  What is it that I do.  And why do I do it?  

This always felt easy to answer when a client asked, I had perfected my rehearsed investment banker answer.

But now it was suddenly the most difficult question ever asked in my professional career.

Here is my most loved female on the planet, the person who wants me to be her hero, and she wants to know what I do.

As she lowered her light saber and stared at me, I told her that just like she would be the ferocious Princess Leah, I would be the persistent Luke Skywalker, 

  

But it was at that moment I realized I wasn’t a hero. I had been sitting in just another investment bank doing the same thing as every other investment banker… serving their goal of more revenue and more profit. That’s what I did.

  

I wasn’t proud, I wasn’t fulfilled and I wasn’t happy with myself.

  

And that’s why I started Ignatious.  For my children.  For every parent and every parent’s child.  

  

I’m not suddenly trying to be a hero.  In fact, I realized after she asked that I’m more of a Yoda than a Luke Skywalker.  That the Bruce Wayne’s and Luke Skywalkers are the the bold entrepreneurs who risked everything to create a better world.  And my gift was in risking everything to help them fulfill this mission so I could tell my daughter that I too helped make her world a better place. And that is why I created Ignatious, and that is why we won’t stop.

  

WEBSITE

  

Tracks visitors and sends us updated information daily/weekly

  

Tracks source of those visitors as well (Google vs. direct typed, vs. from an advertisement vs. Linked, etc.)

  

Website that hides the longer story and only shows the punchline. When you click the read more symbol it expands the the full text where that one punchline is just a small part and comes to life even more.

Then it has a “TMI button to collapse it again”

  
  
  
**